import {NextResponse} from 'next/server';import {db} from '@/lib/db';
export async function GET(){const products=await db.product.findMany({where:{active:true},include:{images:{orderBy:{sort:'asc'}},sizes:true},orderBy:{createdAt:'desc'}});return NextResponse.json(products)}
