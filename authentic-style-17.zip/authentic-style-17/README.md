# AUTHENTIC STYLE 17

E-commerce streetwear maschile predisposto per Next.js + PostgreSQL/Prisma + Stripe + Vercel.

## Avvio
1. Installa Node.js 20+.
2. `npm install`
3. Copia `.env.example` in `.env.local` e inserisci le credenziali.
4. `npx prisma db push`
5. `npm run db:seed`
6. `npm run dev`

## Produzione
Configura PostgreSQL, Stripe e le variabili d'ambiente su Vercel. Prima del lancio completa autenticazione, carrello server-side, webhook Stripe, email transazionali e protezione delle route admin.

Le immagini demo in `public/products` possono essere sostituite con le foto reali del negozio.
