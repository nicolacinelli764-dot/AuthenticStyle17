import { PrismaClient, ProductCategory } from '@prisma/client';
const db=new PrismaClient();
async function main(){
 const products=[
 {name:'Essential Black Tee',slug:'essential-black-tee',description:'T-shirt streetwear maschile dalla linea pulita.',price:3500,category:ProductCategory.TSHIRT,color:'Nero',inventory:20,featured:true,images:['/products/tee-black.jpg'],sizes:['S','M','L','XL']},
 {name:'Core Hoodie',slug:'core-hoodie',description:'Felpa premium dal fit moderno.',price:6500,category:ProductCategory.FELPE,color:'Antracite',inventory:15,bestseller:true,images:['/products/hoodie.jpg'],sizes:['S','M','L','XL','XXL']},
 {name:'Urban Cargo',slug:'urban-cargo',description:'Pantalone cargo streetwear versatile.',price:7200,category:ProductCategory.PANTALONI,color:'Nero',inventory:12,featured:true,images:['/products/cargo.jpg'],sizes:['S','M','L','XL']},
 {name:'17 Signature Cap',slug:'17-signature-cap',description:'Cappello con identità AUTHENTIC STYLE 17.',price:3000,category:ProductCategory.CAPPELLI,color:'Nero',inventory:30,bestseller:true,images:['/products/cap.jpg'],sizes:['UNICA']}
 ];
 for(const p of products){const x=await db.product.upsert({where:{slug:p.slug},update:{...p,images:undefined,sizes:undefined},create:{...p,images:{create:p.images.map((url,i)=>({url,sort:i}))},sizes:{create:p.sizes.map(size=>({size,stock:Math.floor(p.inventory/p.sizes.length)}))}}}); if(x){} }
}
main().finally(()=>db.$disconnect());
